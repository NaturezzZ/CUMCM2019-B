% ��Ҫ˼���ǣ��ڹ������Ĺ����У���С�ĵ���б��
% �ԶԳ���Ϊy�ᣬ�������λ��(4i/pi + bias)��λ��
F = [80,80,80,80,80,80,80,80];
activate = [1,1,0,0,0,0,0,0];
bias = pi/8;
theta = [];
I = 0.0865;
for i = 1:8
    theta(1,i) = pi*i/4 +bias;
end
alpha = 0.14/1.7;
delta = 0;
omega = 0;

% period 1
for i = 1:10000
    M = [0,0,0];
    for j = 1:8
        r = [0.2*sin(theta(1,j))*cos(delta), 0.2*cos(theta(1,j)),-0.2*sin(theta(1,j))*sin(delta)];
        Fj = [F(1,j)*sin(theta(1,j))*cos(alpha), F(1,j)*cos(theta(1,j))*cos(alpha), F(1,j)*sin(alpha)];
        % r
        % Fj
        if activate(1,j)==1
            M = M + cross(r,Fj);   
        end
    end
    delta = delta + omega* 0.1/10000;
    omega = omega + M(1,2)/I * 0.1/10000;
end
"period 1"
["omega","delta";omega,delta]
% period 2
for i = 1:(10000)
    M = [0,0,0];
    for j = 1:8
        r = [0.2*sin(theta(1,j))*cos(delta), 0.2*cos(theta(1,j)),-0.2*sin(theta(1,j))*sin(delta)];
        Fj = [F(1,j)*sin(theta(1,j))*cos(alpha), F(1,j)*cos(theta(1,j))*cos(alpha), F(1,j)*sin(alpha)];
        % r
        % Fj
        %r
        %Fj
        M = M + cross(r,Fj); 
        %cross(r,Fj)
    end
    %"M"
    %M
    delta = delta + omega* 0.1/10000;
    omega = omega + M(1,2)/I * 0.1/10000;
    %omega
    %break;
    %omega
    %break;
end
"period 2"
["omega","delta";omega,delta]

% he noticed he was early and dimished his force
F_backup = F;
for i = 1:8
    if activate(1,i) ==1
        F(1,i) = 1.5*F(1,i);
    end
end
% period 3
for i = 1:(30000)
    M = [0,0,0];
    for j = 1:8
        r = [0.2*sin(theta(1,j))*cos(delta), 0.2*cos(theta(1,j)),-0.2*sin(theta(1,j))*sin(delta)];
        Fj = [F(1,j)*sin(theta(1,j))*cos(alpha), F(1,j)*cos(theta(1,j))*cos(alpha), F(1,j)*sin(alpha)];
        M = M + cross(r,Fj); 
        %r
        %Fj
        %cross(r,Fj)
    end
    delta = delta + omega* 0.1/10000;
    omega = omega + M(1,2)/I * 0.1/10000;
end
"period 3"
["omega","delta";omega,delta]

